export const enum Icon {
  BOFANG = "#icon-bofanganniu", // 播放
  ZANTING = "#icon-zanting", // 暂停
}
